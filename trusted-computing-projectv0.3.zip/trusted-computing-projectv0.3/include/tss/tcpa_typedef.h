
#ifndef __TCPA_TYPEDEF_H__
#define __TCPA_TYPEDEF_H__

#warning including deprecated header file tcpa_typedef.h

#endif
